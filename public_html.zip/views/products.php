<?php
/**
 * Products Page View - With All Sections
 */
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-content">
        <h1 class="hero-title">Handcrafted Breads & Patisserie</h1>
        <p class="hero-subtitle">Experience the art of baking with our freshly prepared artisan breads, decadent cakes, and exquisite pastries.</p>
        <a href="#products" class="cta-button">View Menu</a>
    </div>
</section>

<!-- Products Section -->
<section id="products" class="products-section">
    <div class="container">
        <h2 class="section-title">Our Products</h2>
        <p class="section-subtitle">Freshly baked daily with premium ingredients</p>
        
        <!-- Error Messages -->
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <?php if ($_GET['error'] == 'stock'): ?>
                    <p>⚠️ Sorry, insufficient stock available for this item.</p>
                <?php elseif ($_GET['error'] == 'notfound'): ?>
                    <p>⚠️ Product not found.</p>
                <?php elseif ($_GET['error'] == 'invalid'): ?>
                    <p>⚠️ Invalid request. Please try again.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <div class="products-grid">
            <?php if (empty($products)): ?>
                <p style="text-align: center; grid-column: 1/-1; padding: 2rem;">No products available at the moment.</p>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php if ($product['image']): ?>
                                <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                                     onerror="this.parentElement.innerHTML='<div class=\'product-placeholder\'><span>🥖</span></div>'">
                            <?php else: ?>
                                <div class="product-placeholder">
                                    <span>🥖</span>
                                </div>
                            <?php endif; ?>
                            <?php if ($product['stock'] < 10 && $product['stock'] > 0): ?>
                                <span class="stock-badge">Only <?php echo $product['stock']; ?> left!</span>
                            <?php elseif ($product['stock'] == 0): ?>
                                <span class="stock-badge" style="background: #ff4444;">Out of Stock</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="product-info">
                            <span class="product-category"><?php echo htmlspecialchars($product['category']); ?></span>
                            <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                            
                            <div class="product-footer">
                                <span class="product-price">₹<?php echo number_format($product['price'], 2); ?></span>
                                
                                <?php if ($product['stock'] > 0): ?>
                                    <form method="POST" action="index.php?page=cart&action=add" class="add-to-cart-form">
                                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                        <div class="quantity-selector">
                                            <button type="button" class="qty-btn minus" onclick="decreaseQty(this)">-</button>
                                            <input type="number" name="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>" class="qty-input" readonly>
                                            <button type="button" class="qty-btn plus" onclick="increaseQty(this)">+</button>
                                        </div>
                                        <button type="submit" class="btn-add-cart">Add to Cart</button>
                                    </form>
                                <?php else: ?>
                                    <button class="btn-add-cart" disabled style="background: #ccc; cursor: not-allowed;">Out of Stock</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="about" id="about">
        <div class="container">
            <h2 class="section-title">Our Philosophy</h2>
            <div class="about-content">
                <p>LGR Bakery is built on the foundation of quality ingredients and traditional techniques. We believe the best taste comes from patience, careful preparation, and the finest selection of flour, butter, and natural flavors. From European loaves to classic Indian tea snacks, we bake for every palate.</p>
            </div>
            <div class="stats-container">
                <div class="stat-card">
                    <span class="stat-number">200+</span>
                    <span class="stat-label">Daily Fresh Bakes</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">5+</span>
                    <span class="stat-label">Years of Baking Excellence</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">100%</span>
                    <span class="stat-label">Natural Ingredients</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">150+</span>
                    <span class="stat-label">Customer Reviews (5-Star)</span>
                </div>
            </div>
        </div>
    </section>

 <!-- Contact Section -->
    <section class="contact" id="contact">
        <div class="container">
            <h2 class="section-title">Get in Touch</h2>
            <div class="contact-wrapper">
                <!-- Contact Info Left -->
                <div class="contact-info">
                    <div class="contact-item">
                        <h4>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                            Phone
                        </h4>
                        <p>+91 9951471170</p>
                        <p>+91 40 1234 5678</p>
                    </div>
                    <div class="contact-item">
                        <h4>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                            Email
                        </h4>
                        <p>orders@lgrbakery.in</p>
                        <p>support@lgrbakery.in</p>
                    </div>
                    <div class="contact-item">
                        <h4>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                            Location
                        </h4>
                        <p>Door No. 5, Main Street, Jubilee Hills</p>
                        <p>Hyderabad, Telangana - 500033</p>
                    </div>
                </div>

                <!-- Contact Form Right -->
                <div class="contact-form-card">
                    <form id="contact-form">
                        <div class="form-group">
                            <label>Your Name</label>
                            <input type="text" class="form-control" required placeholder="John Doe">
                        </div>
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" class="form-control" required placeholder="john@example.com">
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea class="form-control" rows="4" required placeholder="Tell us about your custom order or query..."></textarea>
                        </div>
                        <button type="submit" class="btn-add" style="border-radius: 5px;">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
