<?php
/**
 * Shopping Cart View - Fixed Image Display
 */
require_once __DIR__ . '/../includes/header.php';

// Calculate cart totals
$cart_total = 0;
$cart_count = 0;

if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_total += $item['price'] * $item['quantity'];
        $cart_count += $item['quantity'];
    }
}
?>

<section class="cart-section">
    <div class="container">
        <h1 class="page-title">Shopping Cart</h1>
        
        <?php if (isset($_GET['status']) && $_GET['status'] == 'added'): ?>
            <div class="alert alert-success">
                <p>✓ Item added to cart successfully!</p>
            </div>
        <?php endif; ?>
        
        <?php if (empty($_SESSION['cart'])): ?>
            <div class="empty-cart">
                <div class="empty-cart-icon">🛒</div>
                <h2>Your cart is empty</h2>
                <p>Browse our products and add items to your cart</p>
                <a href="index.php?page=products" class="cta-button">Continue Shopping</a>
            </div>
        <?php else: ?>
            <div class="cart-content">
                <div class="cart-items">
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <div class="cart-item">
                            <div class="cart-item-image">
                                <?php if (!empty($item['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($item['image']); ?>" 
                                         alt="<?php echo htmlspecialchars($item['name']); ?>"
                                         onerror="this.parentElement.innerHTML='<div class=\'cart-placeholder\'>🥖</div>'">
                                <?php else: ?>
                                    <div class="cart-placeholder">🥖</div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="cart-item-details">
                                <h3 class="cart-item-name"><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p class="cart-item-price">₹<?php echo number_format($item['price'], 2); ?></p>
                            </div>
                            
                            <div class="cart-item-actions">
                                <form method="POST" action="index.php?page=cart&action=update" class="quantity-form">
                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                    <div class="quantity-selector">
                                        <button type="button" class="qty-btn minus" onclick="decreaseQty(this)">-</button>
                                        <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" 
                                               min="1" class="qty-input" onchange="this.form.submit()">
                                        <button type="button" class="qty-btn plus" onclick="increaseQty(this)">+</button>
                                    </div>
                                </form>
                                
                                <p class="cart-item-subtotal">₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></p>
                                
                                <a href="index.php?page=cart&action=remove&id=<?php echo $item['id']; ?>" 
                                   class="btn-remove" onclick="return confirm('Remove this item from cart?')">
                                    ✕
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="cart-summary">
                    <h3 class="summary-title">Order Summary</h3>
                    
                    <div class="summary-row">
                        <span>Items (<?php echo $cart_count; ?>)</span>
                        <span>₹<?php echo number_format($cart_total, 2); ?></span>
                    </div>
                    
                    <div class="summary-row">
                        <span>Delivery</span>
                        <span class="free-badge">FREE</span>
                    </div>
                    
                    <hr class="summary-divider">
                    
                    <div class="summary-row summary-total">
                        <span>Total Amount</span>
                        <span>₹<?php echo number_format($cart_total, 2); ?></span>
                    </div>
                    
                    <a href="index.php?page=checkout" class="btn-checkout">Proceed to Checkout</a>
                    <a href="index.php?page=products" class="btn-continue">Continue Shopping</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
