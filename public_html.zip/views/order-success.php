<?php
/**
 * Order Success Page
 */
require_once __DIR__ . '/../includes/header.php';

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
?>

<section class="success-section">
    <div class="container">
        <div class="success-content">
            <div class="success-icon">✓</div>
            <h1 class="success-title">Order Placed Successfully!</h1>
            <p class="success-message">Thank you for your order. Your order has been confirmed.</p>
            
            <div class="order-details">
                <p class="order-id">Order ID: <strong>#<?php echo str_pad($order_id, 6, '0', STR_PAD_LEFT); ?></strong></p>
                <p class="order-info">You will receive a confirmation email shortly with your order details.</p>
            </div>
            
            <div class="success-actions">
                <a href="index.php?page=products" class="cta-button">Continue Shopping</a>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
