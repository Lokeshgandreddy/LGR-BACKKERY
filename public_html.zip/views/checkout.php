<?php
/**
 * Checkout Page View
 */
require_once __DIR__ . '/../includes/header.php';

// Calculate cart totals
$cart_total = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_total += $item['price'] * $item['quantity'];
    }
}
?>

<section class="checkout-section">
    <div class="container">
        <h1 class="page-title">Checkout</h1>
        
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <?php if ($_GET['error'] == 'required'): ?>
                    <p>⚠️ Please fill in all required fields.</p>
                <?php elseif ($_GET['error'] == 'email'): ?>
                    <p>⚠️ Please enter a valid email address.</p>
                <?php elseif ($_GET['error'] == 'failed'): ?>
                    <p>⚠️ Order failed. Please try again or contact support.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <div class="checkout-content">
            <div class="checkout-form-section">
                <h2 class="section-heading">Delivery Information</h2>
                
                <form method="POST" action="index.php?page=checkout" class="checkout-form">
                    <div class="form-group">
                        <label for="name">Full Name *</label>
                        <input type="text" id="name" name="name" required 
                               placeholder="Enter your full name">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" required 
                               placeholder="your@email.com">
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number *</label>
                        <input type="tel" id="phone" name="phone" required 
                               placeholder="+91 98765 43210">
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Delivery Address *</label>
                        <textarea id="address" name="address" rows="4" required 
                                  placeholder="House No., Street, Area, City, State, PIN Code"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-place-order">Place Order</button>
                        <a href="index.php?page=cart" class="btn-back">Back to Cart</a>
                    </div>
                </form>
            </div>
            
            <div class="order-summary-section">
                <h2 class="section-heading">Order Summary</h2>
                
                <div class="summary-items">
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <div class="summary-item">
                            <div class="summary-item-info">
                                <h4><?php echo htmlspecialchars($item['name']); ?></h4>
                                <p>Qty: <?php echo $item['quantity']; ?> × ₹<?php echo number_format($item['price'], 2); ?></p>
                            </div>
                            <div class="summary-item-price">
                                ₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="summary-totals">
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span>₹<?php echo number_format($cart_total, 2); ?></span>
                    </div>
                    
                    <div class="summary-row">
                        <span>Delivery Charges</span>
                        <span class="free-badge">FREE</span>
                    </div>
                    
                    <hr class="summary-divider">
                    
                    <div class="summary-row summary-total">
                        <span>Total Amount</span>
                        <span>₹<?php echo number_format($cart_total, 2); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
