<?php
/**
 * Admin Account Creation Script
 * Uses existing `users` table with is_admin flag
 * Run ONCE, then DELETE this file for security
 */

// Database configuration
$host = 'srv1988.hstgr.io';
$dbname = 'u557053954_Lokesh';
$username = 'u557053954_Lokesh';
$password = 'Lokesh@7070';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $plain_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validation
    $errors = [];
    
    if (empty($name) || strlen($name) < 3) {
        $errors[] = "Name must be at least 3 characters";
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    }
    
    if (strlen($plain_password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }
    
    if ($plain_password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }
    
    // Check if user already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn() > 0) {
        $errors[] = "User with this email already exists. Update existing user to admin instead?";
    }
    
    if (empty($errors)) {
        // Hash password using bcrypt
        $hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);
        
        // Insert admin user into existing users table
        $stmt = $pdo->prepare("
            INSERT INTO users (name, email, password, is_admin, created_at, updated_at) 
            VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ");
        
        if ($stmt->execute([$name, $email, $hashed_password])) {
            $success_message = "Admin account created successfully! User ID: " . $pdo->lastInsertId();
            $admin_created = true;
            
            // Show login credentials
            echo "<script>
                alert('Admin Created! Email: $email | Password: [your chosen password]');
            </script>";
        } else {
            $errors[] = "Failed to create admin account";
        }
    }
}

// Check existing admin count
$admin_count = $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin = 1")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin Account - LGR Bakery</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh; display: flex; align-items: center;
            justify-content: center; padding: 20px;
        }
        .setup-container {
            background: white; padding: 3rem 2.5rem; border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3); max-width: 500px; width: 100%;
        }
        .setup-header { text-align: center; margin-bottom: 2rem; }
        .setup-header h1 { font-size: 2rem; color: #333; margin-bottom: 0.5rem; }
        .setup-header p { color: #666; font-size: 0.95rem; }
        .alert {
            padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem;
        }
        .alert-error {
            background: #fee; border: 1px solid #fcc; color: #c00;
        }
        .alert-success {
            background: #efe; border: 1px solid #cfc; color: #080;
        }
        .alert ul { margin: 0; padding-left: 1.5rem; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label {
            display: block; font-weight: 600; margin-bottom: 0.5rem; color: #333;
        }
        .form-group input {
            width: 100%; padding: 14px 18px; border: 2px solid #e0e0e0;
            border-radius: 10px; font-family: 'Poppins', sans-serif; font-size: 1rem;
            transition: all 0.3s ease;
        }
        .form-group input:focus {
            outline: none; border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .btn-create {
            width: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; padding: 15px; border: none; border-radius: 10px;
            font-weight: 600; font-size: 1.1rem; cursor: pointer;
            transition: transform 0.3s ease;
        }
        .btn-create:hover {
            transform: translateY(-2px); box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        .warning-box {
            background: #fff3cd; border: 2px solid #ffc107; padding: 1rem;
            border-radius: 10px; margin-top: 1.5rem; text-align: center;
        }
        .warning-box strong {
            color: #856404; display: block; margin-bottom: 0.5rem;
        }
        .info-box {
            background: #d1ecf1; border: 1px solid #bee5eb; padding: 1rem;
            border-radius: 10px; margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="setup-container">
        <div class="setup-header">
            <h1>🔐 Create Admin Account</h1>
            <p>Using existing users table (is_admin=1)</p>
        </div>
        
        <?php if ($admin_count > 0): ?>
            <div class="alert alert-info">
                <p><strong>ℹ️ Info:</strong> <?php echo $admin_count; ?> admin(s) already exist.</p>
                <p style="margin-top: 0.5rem;">You can create additional admin accounts or <a href="index.php?page=admin&view=login">login here</a>.</p>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success">
                <p><strong>✓ Success!</strong> <?php echo htmlspecialchars($success_message); ?></p>
                <p style="margin-top: 1rem;"><a href="index.php?page=admin&view=login">→ Go to Admin Login</a></p>
            </div>
        <?php endif; ?>
        
        <?php if (!isset($admin_created)): ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" required 
                           placeholder="John Doe" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" required 
                           placeholder="admin@lgrbakery.in" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required 
                           placeholder="Minimum 8 characters">
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required 
                           placeholder="Re-enter password">
                </div>
                
                <button type="submit" class="btn-create">Create Admin Account</button>
            </form>
            
            <div class="warning-box">
                <strong>⚠️ SECURITY WARNING</strong>
                <p>Delete this file immediately after creating your admin account!</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
