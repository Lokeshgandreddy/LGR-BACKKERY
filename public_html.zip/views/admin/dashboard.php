<?php
/**
 * Admin Dashboard
 */
require_once __DIR__ . '/../../includes/header.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php?page=admin&view=login');
    exit();
}
?>

<section class="admin-section">
    <div class="container">
        <div class="admin-header">
            <h1 class="page-title">Admin Dashboard</h1>
            <div class="admin-actions">
                <span class="admin-welcome">Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
                <a href="index.php?page=admin&view=logout" class="btn-logout">Logout</a>
            </div>
        </div>
        
        <div class="admin-nav">
            <a href="index.php?page=admin&view=dashboard" class="admin-nav-link active">Dashboard</a>
            <a href="index.php?page=admin&view=orders" class="admin-nav-link">Orders</a>
            <a href="index.php" class="admin-nav-link">View Store</a>
        </div>
        
        <div class="dashboard-stats">
            <div class="stat-card">
                <div class="stat-icon">📦</div>
                <div class="stat-info">
                    <h3><?php echo $total_orders; ?></h3>
                    <p>Total Orders</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-info">
                    <h3>₹<?php echo number_format($total_revenue, 2); ?></h3>
                    <p>Total Revenue</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">⏳</div>
                <div class="stat-info">
                    <h3><?php echo $pending_orders; ?></h3>
                    <p>Pending Orders</p>
                </div>
            </div>
        </div>
        
        <div class="dashboard-actions">
            <a href="index.php?page=admin&view=orders" class="cta-button">View All Orders</a>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
