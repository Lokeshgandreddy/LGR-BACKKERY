<?php
/**
 * Admin Orders Page - Enhanced with Full Management Features
 */
require_once __DIR__ . '/../../includes/header.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php?page=admin&view=login');
    exit();
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$date_filter = isset($_GET['date']) ? $_GET['date'] : '';

// Calculate order statistics
$total_orders = count($orders);
$pending_orders = 0;
$completed_orders = 0;
$cancelled_orders = 0;
$total_revenue = 0;

foreach ($orders as $order) {
    if ($order['status'] === 'pending') $pending_orders++;
    if ($order['status'] === 'completed') $completed_orders++;
    if ($order['status'] === 'cancelled') $cancelled_orders++;
    if ($order['status'] !== 'cancelled') $total_revenue += $order['total_amount'];
}
?>

<section class="admin-section">
    <div class="container">
        <div class="admin-header">
            <h1 class="page-title">Order Management</h1>
            <div class="admin-actions">
                <span class="admin-welcome">Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
                <a href="index.php?page=admin&view=logout" class="btn-logout">Logout</a>
            </div>
        </div>
        
        <!-- Navigation Tabs -->
        <div class="admin-nav">
            <a href="index.php?page=admin&view=dashboard" class="admin-nav-link">Dashboard</a>
            <a href="index.php?page=admin&view=orders" class="admin-nav-link active">Orders</a>
            <a href="index.php" class="admin-nav-link">View Store</a>
        </div>
        
        <!-- Success/Error Messages -->
        <?php if (isset($_GET['updated']) && $_GET['updated'] == 'success'): ?>
            <div class="alert alert-success">
                <p>✓ Order status updated successfully!</p>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['deleted']) && $_GET['deleted'] == 'success'): ?>
            <div class="alert alert-success">
                <p>✓ Order deleted successfully!</p>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <p>⚠️ <?php echo htmlspecialchars($_GET['error']); ?></p>
            </div>
        <?php endif; ?>
        
        <!-- Order Statistics Cards -->
        <div class="dashboard-stats" style="margin-bottom: 2rem;">
            <div class="stat-card">
                <div class="stat-icon">📦</div>
                <div class="stat-info">
                    <h3><?php echo $total_orders; ?></h3>
                    <p>Total Orders</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">⏳</div>
                <div class="stat-info">
                    <h3><?php echo $pending_orders; ?></h3>
                    <p>Pending Orders</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-info">
                    <h3><?php echo $completed_orders; ?></h3>
                    <p>Completed Orders</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-info">
                    <h3>₹<?php echo number_format($total_revenue, 0); ?></h3>
                    <p>Total Revenue</p>
                </div>
            </div>
        </div>
        
        <!-- Filters and Search Bar -->
        <div class="orders-toolbar">
            <form method="GET" action="index.php" class="orders-filter-form">
                <input type="hidden" name="page" value="admin">
                <input type="hidden" name="view" value="orders">
                
                <div class="filter-group">
                    <label for="status-filter">Status:</label>
                    <select name="status" id="status-filter" onchange="this.form.submit()">
                        <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Orders</option>
                        <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="processing" <?php echo $status_filter === 'processing' ? 'selected' : ''; ?>>Processing</option>
                        <option value="completed" <?php echo $status_filter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="cancelled" <?php echo $status_filter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="date-filter">Date:</label>
                    <select name="date" id="date-filter" onchange="this.form.submit()">
                        <option value="" <?php echo $date_filter === '' ? 'selected' : ''; ?>>All Time</option>
                        <option value="today" <?php echo $date_filter === 'today' ? 'selected' : ''; ?>>Today</option>
                        <option value="week" <?php echo $date_filter === 'week' ? 'selected' : ''; ?>>This Week</option>
                        <option value="month" <?php echo $date_filter === 'month' ? 'selected' : ''; ?>>This Month</option>
                    </select>
                </div>
                
                <div class="filter-group search-group">
                    <input type="text" name="search" placeholder="Search by order ID, customer name, email..." 
                           value="<?php echo htmlspecialchars($search_query); ?>" class="search-input">
                    <button type="submit" class="btn-search">🔍 Search</button>
                </div>
                
                <?php if ($status_filter !== 'all' || $search_query !== '' || $date_filter !== ''): ?>
                    <a href="index.php?page=admin&view=orders" class="btn-clear-filters">Clear Filters</a>
                <?php endif; ?>
            </form>
            
            <div class="toolbar-actions">
                <button onclick="window.print()" class="btn-toolbar">🖨️ Print</button>
                <button onclick="exportOrders()" class="btn-toolbar">📥 Export CSV</button>
            </div>
        </div>
        
        <!-- Orders List -->
        <?php if (empty($orders)): ?>
            <div class="no-orders">
                <div class="empty-icon">📦</div>
                <h3>No orders found</h3>
                <p><?php echo $status_filter !== 'all' ? 'No ' . $status_filter . ' orders at the moment.' : 'No orders have been placed yet.'; ?></p>
            </div>
        <?php else: ?>
            <div class="orders-list">
                <?php foreach ($orders as $order): ?>
                    <div class="order-card" id="order-<?php echo $order['id']; ?>">
                        <!-- Order Header -->
                        <div class="order-header">
                            <div class="order-id">
                                <strong>Order #<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong>
                                <span class="order-date">
                                    📅 <?php echo date('M d, Y h:i A', strtotime($order['created_at'])); ?>
                                </span>
                            </div>
                            
                            <div class="order-header-actions">
                                <span class="order-status status-<?php echo $order['status']; ?>">
                                    <?php 
                                    $status_icons = [
                                        'pending' => '⏳',
                                        'processing' => '⚙️',
                                        'completed' => '✅',
                                        'cancelled' => '❌'
                                    ];
                                    echo $status_icons[$order['status']] ?? '📦';
                                    ?> 
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                                
                                <!-- Quick Actions Dropdown -->
                                <div class="order-actions-dropdown">
                                    <button class="btn-actions" onclick="toggleDropdown(<?php echo $order['id']; ?>)">
                                        ⚙️ Actions ▼
                                    </button>
                                    <div class="dropdown-menu" id="dropdown-<?php echo $order['id']; ?>">
                                        <?php if ($order['status'] !== 'completed'): ?>
                                            <a href="index.php?page=admin&view=orders&action=update_status&id=<?php echo $order['id']; ?>&status=completed" 
                                               class="dropdown-item" onclick="return confirm('Mark this order as completed?')">
                                                ✅ Mark Completed
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php if ($order['status'] === 'pending'): ?>
                                            <a href="index.php?page=admin&view=orders&action=update_status&id=<?php echo $order['id']; ?>&status=processing" 
                                               class="dropdown-item">
                                                ⚙️ Mark Processing
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php if ($order['status'] !== 'cancelled'): ?>
                                            <a href="index.php?page=admin&view=orders&action=update_status&id=<?php echo $order['id']; ?>&status=cancelled" 
                                               class="dropdown-item" onclick="return confirm('Cancel this order?')">
                                                ❌ Cancel Order
                                            </a>
                                        <?php endif; ?>
                                        
                                        <a href="javascript:void(0)" onclick="printOrder(<?php echo $order['id']; ?>)" class="dropdown-item">
                                            🖨️ Print Invoice
                                        </a>
                                        
                                        <a href="javascript:void(0)" onclick="viewOrderDetails(<?php echo $order['id']; ?>)" class="dropdown-item">
                                            👁️ View Details
                                        </a>
                                        
                                        <hr style="margin: 0.5rem 0; border: none; border-top: 1px solid #e0e0e0;">
                                        
                                        <a href="index.php?page=admin&view=orders&action=delete&id=<?php echo $order['id']; ?>" 
                                           class="dropdown-item delete-item" 
                                           onclick="return confirm('Are you sure you want to delete this order? This action cannot be undone.')">
                                            🗑️ Delete Order
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Customer Information -->
                        <div class="order-customer">
                            <div class="customer-grid">
                                <div class="customer-info-item">
                                    <strong>👤 Customer:</strong> 
                                    <span><?php echo htmlspecialchars($order['customer_name']); ?></span>
                                </div>
                                <div class="customer-info-item">
                                    <strong>📧 Email:</strong> 
                                    <a href="mailto:<?php echo htmlspecialchars($order['customer_email']); ?>">
                                        <?php echo htmlspecialchars($order['customer_email']); ?>
                                    </a>
                                </div>
                                <div class="customer-info-item">
                                    <strong>📱 Phone:</strong> 
                                    <a href="tel:<?php echo htmlspecialchars($order['customer_phone']); ?>">
                                        <?php echo htmlspecialchars($order['customer_phone']); ?>
                                    </a>
                                </div>
                                <div class="customer-info-item">
                                    <strong>📍 Address:</strong> 
                                    <span><?php echo htmlspecialchars($order['customer_address']); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Order Items -->
                        <div class="order-items">
                            <h4>📦 Order Items (<?php echo count($order['items']); ?>):</h4>
                            <div class="items-table-wrapper">
                                <table class="items-table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($order['items'] as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                                <td>₹<?php echo number_format($item['price'], 2); ?></td>
                                                <td><?php echo $item['quantity']; ?>x</td>
                                                <td>₹<?php echo number_format($item['subtotal'], 2); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <!-- Order Total and Status Update -->
                        <div class="order-footer">
                            <div class="order-total">
                                <strong>💰 Total Amount: ₹<?php echo number_format($order['total_amount'], 2); ?></strong>
                            </div>
                            
                            <?php if ($order['status'] !== 'completed' && $order['status'] !== 'cancelled'): ?>
                                <form method="POST" action="index.php?page=admin&view=orders&action=update_status" class="status-update-form">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <select name="new_status" class="status-select" onchange="this.form.submit()">
                                        <option value="">Change Status...</option>
                                        <option value="pending" <?php echo $order['status'] === 'pending' ? 'disabled' : ''; ?>>
                                            Pending
                                        </option>
                                        <option value="processing" <?php echo $order['status'] === 'processing' ? 'disabled' : ''; ?>>
                                            Processing
                                        </option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Additional CSS for New Features -->
<style>
.orders-toolbar {
    background: var(--white);
    padding: 1.5rem;
    border-radius: 15px;
    margin-bottom: 2rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    gap: 1.5rem;
    flex-wrap: wrap;
}

.orders-filter-form {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
    align-items: flex-end;
    flex: 1;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
}

.filter-group label {
    font-weight: 600;
    font-size: 0.85rem;
    color: var(--dark-gray);
}

.filter-group select {
    padding: 0.6rem 1rem;
    border: 2px solid var(--light-gray);
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.9rem;
    background: var(--white);
    cursor: pointer;
    transition: border-color 0.3s ease;
    min-width: 150px;
}

.filter-group select:focus {
    outline: none;
    border-color: var(--accent-gold);
}

.search-group {
    flex: 1;
    min-width: 250px;
}

.search-input {
    width: 100%;
    padding: 0.6rem 1rem;
    border: 2px solid var(--light-gray);
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.9rem;
    transition: border-color 0.3s ease;
}

.search-input:focus {
    outline: none;
    border-color: var(--accent-gold);
}

.btn-search {
    padding: 0.6rem 1.5rem;
    background: var(--black);
    color: var(--white);
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    white-space: nowrap;
    font-size: 0.9rem;
}

.btn-search:hover {
    background: var(--accent-gold);
    color: var(--black);
}

.btn-clear-filters {
    padding: 0.6rem 1rem;
    background: var(--light-gray);
    color: var(--black);
    text-decoration: none;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s ease;
    white-space: nowrap;
    font-size: 0.85rem;
    display: inline-block;
}

.btn-clear-filters:hover {
    background: var(--dark-gray);
    color: var(--white);
}

.toolbar-actions {
    display: flex;
    gap: 0.5rem;
}

.btn-toolbar {
    padding: 0.6rem 1rem;
    background: var(--white);
    color: var(--black);
    border: 2px solid var(--light-gray);
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.85rem;
    white-space: nowrap;
}

.btn-toolbar:hover {
    background: var(--light-gray);
    border-color: var(--dark-gray);
}

.order-header-actions {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.order-actions-dropdown {
    position: relative;
}

.btn-actions {
    padding: 0.5rem 1rem;
    background: var(--white);
    color: var(--black);
    border: 2px solid var(--light-gray);
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.85rem;
    white-space: nowrap;
}

.btn-actions:hover {
    background: var(--light-gray);
}

.dropdown-menu {
    display: none;
    position: absolute;
    top: 100%;
    right: 0;
    background: var(--white);
    border: 2px solid var(--light-gray);
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    z-index: 100;
    min-width: 200px;
    margin-top: 0.5rem;
}

.dropdown-menu.show {
    display: block;
}

.dropdown-item {
    display: block;
    padding: 0.8rem 1.2rem;
    color: var(--black);
    text-decoration: none;
    font-size: 0.9rem;
    transition: all 0.3s ease;
    border-bottom: 1px solid var(--light-gray);
}

.dropdown-item:last-child {
    border-bottom: none;
}

.dropdown-item:hover {
    background: var(--light-gray);
}

.dropdown-item.delete-item {
    color: #ff4444;
}

.dropdown-item.delete-item:hover {
    background: #ffe6e6;
}

.customer-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
}

.customer-info-item {
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
}

.customer-info-item strong {
    color: var(--dark-gray);
    font-size: 0.85rem;
}

.customer-info-item a {
    color: var(--accent-gold);
    text-decoration: none;
}

.customer-info-item a:hover {
    text-decoration: underline;
}

.order-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 2px solid var(--light-gray);
    flex-wrap: wrap;
    gap: 1rem;
}

.status-update-form {
    display: flex;
    align-items: center;
}

.status-select {
    padding: 0.6rem 1rem;
    border: 2px solid var(--light-gray);
    border-radius: 8px;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    background: var(--white);
}

.status-select:focus {
    outline: none;
    border-color: var(--accent-gold);
}

.empty-icon {
    font-size: 4rem;
    margin-bottom: 1rem;
}

.no-orders h3 {
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
    color: var(--black);
}

.items-table-wrapper {
    overflow-x: auto;
}

.status-processing {
    background: #e3f2fd;
    color: #1976d2;
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    .orders-toolbar {
        flex-direction: column;
        align-items: stretch;
    }
    
    .orders-filter-form {
        flex-direction: column;
    }
    
    .filter-group select,
    .search-input {
        width: 100%;
    }
    
    .toolbar-actions {
        width: 100%;
    }
    
    .btn-toolbar {
        flex: 1;
    }
    
    .customer-grid {
        grid-template-columns: 1fr;
    }
    
    .order-footer {
        flex-direction: column;
        align-items: stretch;
    }
    
    .status-select {
        width: 100%;
    }
}

/* Print Styles */
@media print {
    .navbar,
    .admin-nav,
    .admin-actions,
    .orders-toolbar,
    .btn-actions,
    .status-update-form,
    .footer {
        display: none !important;
    }
    
    .order-card {
        page-break-inside: avoid;
        box-shadow: none;
        border: 1px solid #000;
    }
}
</style>

<!-- JavaScript for Interactive Features -->
<script>
// Toggle dropdown menu
function toggleDropdown(orderId) {
    const dropdown = document.getElementById('dropdown-' + orderId);
    const allDropdowns = document.querySelectorAll('.dropdown-menu');
    
    // Close all other dropdowns
    allDropdowns.forEach(d => {
        if (d.id !== 'dropdown-' + orderId) {
            d.classList.remove('show');
        }
    });
    
    // Toggle current dropdown
    dropdown.classList.toggle('show');
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    if (!event.target.closest('.order-actions-dropdown')) {
        document.querySelectorAll('.dropdown-menu').forEach(d => {
            d.classList.remove('show');
        });
    }
});

// Print specific order
function printOrder(orderId) {
    const orderCard = document.getElementById('order-' + orderId);
    const printWindow = window.open('', '', 'height=600,width=800');
    
    printWindow.document.write('<html><head><title>Order #' + String(orderId).padStart(6, '0') + '</title>');
    printWindow.document.write('<style>');
    printWindow.document.write('body { font-family: Arial, sans-serif; padding: 20px; }');
    printWindow.document.write('table { width: 100%; border-collapse: collapse; margin: 20px 0; }');
    printWindow.document.write('th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }');
    printWindow.document.write('th { background: #f5f5f5; }');
    printWindow.document.write('.header { text-align: center; margin-bottom: 30px; }');
    printWindow.document.write('</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<div class="header"><h1>LGR Bakery</h1><h2>Order Invoice</h2></div>');
    printWindow.document.write(orderCard.innerHTML);
    printWindow.document.write('</body></html>');
    
    printWindow.document.close();
    printWindow.print();
}

// View order details (can be enhanced with modal)
function viewOrderDetails(orderId) {
    const orderCard = document.getElementById('order-' + orderId);
    orderCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    orderCard.style.border = '3px solid #D4AF37';
    
    setTimeout(() => {
        orderCard.style.border = '2px solid var(--light-gray)';
    }, 2000);
}

// Export orders to CSV
function exportOrders() {
    const orders = <?php echo json_encode($orders); ?>;
    
    if (orders.length === 0) {
        alert('No orders to export!');
        return;
    }
    
    let csv = 'Order ID,Date,Customer Name,Email,Phone,Address,Status,Total Amount\n';
    
    orders.forEach(order => {
        csv += `#${String(order.id).padStart(6, '0')},`;
        csv += `"${order.created_at}",`;
        csv += `"${order.customer_name}",`;
        csv += `"${order.customer_email}",`;
        csv += `"${order.customer_phone}",`;
        csv += `"${order.customer_address}",`;
        csv += `${order.status},`;
        csv += `₹${order.total_amount}\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'orders_' + new Date().toISOString().split('T')[0] + '.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
