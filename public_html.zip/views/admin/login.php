<?php
/**
 * Admin Login Page - With Navbar & Footer
 */
require_once __DIR__ . '/../../includes/header.php';
?>

<section class="admin-login-section">
    <div class="container">
        <div class="admin-login-container">
            <div class="admin-login-box">
                <div class="admin-logo">
                    <h1>LGR Bakery</h1>
                    <p>Admin Panel</p>
                </div>
                
                <?php if (isset($_GET['error']) && $_GET['error'] == 'invalid'): ?>
                    <div class="alert alert-error">
                        <p>⚠️ Invalid email or password</p>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="index.php?page=admin&view=login" class="admin-login-form">
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required 
                               placeholder="admin@lgrbakery.in" autocomplete="username">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required 
                               placeholder="••••••••" autocomplete="current-password">
                    </div>
                    
                    <button type="submit" class="btn-admin-login">Login</button>
                </form>
                
                <div class="admin-footer-link">
                    <p>Authorized personnel only</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
