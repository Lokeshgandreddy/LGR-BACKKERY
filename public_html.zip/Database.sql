-- =====================================================
-- LGR Bakery E-Commerce Database Schema
-- Database: ecommerce_db
-- With exact products and images from index.html
-- =====================================================

CREATE DATABASE IF NOT EXISTS ecommerce_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ecommerce_db;

-- =====================================================
-- Table: users
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    password VARCHAR(255),
    is_admin TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_is_admin (is_admin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Table: products
-- =====================================================
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    image VARCHAR(500),
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_stock (stock)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Table: orders
-- =====================================================
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_address TEXT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Table: order_items
-- =====================================================
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_order_id (order_id),
    INDEX idx_product_id (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Insert Default Admin User
-- Email: admin@lgrbakery.in
-- Password: admin123
-- =====================================================
INSERT INTO users (name, email, password, is_admin) VALUES 
('Admin User', 'admin@lgrbakery.in', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);

-- =====================================================
-- Insert Sample Products (EXACT FROM INDEX.HTML)
-- Using Unsplash images exactly as in original design
-- =====================================================
INSERT INTO products (name, description, price, stock, category, image) VALUES
('Artisan Sourdough Loaf', 'Traditional European-style sourdough bread with crispy crust and soft interior', 320.00, 50, 'Breads', 'https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=400&h=300&fit=crop'),

('Red Velvet Pastry', 'Rich red velvet with cream cheese frosting, perfect for celebrations', 150.00, 100, 'Pastries', 'https://images.unsplash.com/photo-1586985289688-ca3cf47d3e6e?w=400&h=300&fit=crop'),

('Almond Croissant', 'Flaky French croissant filled with sweet almond paste and topped with sliced almonds', 180.00, 75, 'Pastries', 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&h=300&fit=crop'),

('Classic Chocolate Truffle', 'Decadent chocolate celebration cake with rich truffle layers', 650.00, 20, 'Cakes', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop'),

('Spicy Veg Puff', 'Golden puff pastry with spiced vegetable filling - Indian tea time favorite', 45.00, 150, 'Snacks', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&h=300&fit=crop'),

('Whole Wheat Sandwich Bread', 'Healthy whole wheat bread perfect for daily sandwiches', 90.00, 80, 'Breads', 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop'),

('Blueberry Cheesecake Slice', 'Creamy New York style cheesecake with fresh blueberry topping', 220.00, 40, 'Cakes', 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=400&h=300&fit=crop'),

('Chicken Patties', 'Savory chicken-filled pastry with aromatic Indian spices', 60.00, 120, 'Snacks', 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&h=300&fit=crop'),

('Dilkush Sweet Bun', 'Traditional sweet bun filled with coconut and dry fruits', 80.00, 90, 'Pastries', 'https://images.unsplash.com/photo-1509365465985-25d11c17e812?w=400&h=300&fit=crop'),

('Chocolate Chip Cookie Pack', 'Pack of 6 fresh chocolate chip cookies made with premium chocolate', 120.00, 100, 'Cookies', 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400&h=300&fit=crop'),

('Multigrain Bread', 'Nutritious bread with oats, flax seeds, and sunflower seeds', 110.00, 60, 'Breads', 'https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=400&h=300&fit=crop'),

('Butter Naan', 'Soft Indian flatbread brushed with butter (pack of 4)', 80.00, 85, 'Breads', 'https://images.unsplash.com/photo-1566843972142-a7fcb70de797?w=400&h=300&fit=crop'),

('Vanilla Cupcakes', 'Light vanilla cupcakes with buttercream frosting (pack of 6)', 180.00, 65, 'Cakes', 'https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?w=400&h=300&fit=crop'),

('Masala Pav', 'Soft dinner rolls perfect with curry (pack of 4)', 40.00, 110, 'Breads', 'https://images.unsplash.com/photo-1585399000684-d2f72660f092?w=400&h=300&fit=crop'),

('Black Forest Cake', 'Classic chocolate cake with cherry filling and whipped cream (1kg)', 800.00, 15, 'Cakes', 'https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?w=400&h=300&fit=crop');
