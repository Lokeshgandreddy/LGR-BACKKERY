<?php
/**
 * Product Controller
 */

require_once __DIR__ . '/../models/Product.php';

class ProductController {
    private $db;
    private $product;
    
    public function __construct($db) {
        $this->db = $db;
        $this->product = new Product($db);
    }
    
    /**
     * Display products page
     */
    public function index() {
        $products = $this->product->getAll();
        require_once __DIR__ . '/../views/products.php';
    }
}
?>
