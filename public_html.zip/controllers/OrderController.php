<?php
/**
 * Order Controller
 * Handles order placement and management
 */

require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/OrderItem.php';
require_once __DIR__ . '/../models/Product.php';

class OrderController {
    private $db;
    private $order;
    private $orderItem;
    private $product;
    
    /**
     * Constructor
     * @param mysqli $db Database connection
     */
    public function __construct($db) {
        $this->db = $db;
        $this->order = new Order($db);
        $this->orderItem = new OrderItem($db);
        $this->product = new Product($db);
    }
    
    /**
     * Show checkout page
     */
    public function showCheckout() {
        if (empty($_SESSION['cart'])) {
            header('Location: index.php?page=products');
            exit();
        }
        
        require_once __DIR__ . '/../views/checkout.php';
    }
    
    /**
     * Place order
     */
    public function placeOrder() {
        if (empty($_SESSION['cart'])) {
            header('Location: index.php?page=products');
            exit();
        }
        
        // Validate form data
        $customer_name = htmlspecialchars(trim($_POST['name'] ?? ''));
        $customer_email = htmlspecialchars(trim($_POST['email'] ?? ''));
        $customer_phone = htmlspecialchars(trim($_POST['phone'] ?? ''));
        $customer_address = htmlspecialchars(trim($_POST['address'] ?? ''));
        
        if (empty($customer_name) || empty($customer_email) || empty($customer_phone) || empty($customer_address)) {
            header('Location: index.php?page=checkout&error=required');
            exit();
        }
        
        // Validate email
        if (!filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
            header('Location: index.php?page=checkout&error=email');
            exit();
        }
        
        // Calculate total
        $total = 0;
        foreach ($_SESSION['cart'] as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        
        // Begin transaction
        $this->db->begin_transaction();
        
        try {
            // Create order
            $this->order->user_id = $_SESSION['user_id'];
            $this->order->customer_name = $customer_name;
            $this->order->customer_email = $customer_email;
            $this->order->customer_phone = $customer_phone;
            $this->order->customer_address = $customer_address;
            $this->order->total_amount = $total;
            
            $order_id = $this->order->create();
            
            if (!$order_id) {
                throw new Exception("Failed to create order");
            }
            
            // Create order items and update stock
            foreach ($_SESSION['cart'] as $item) {
                // Check stock availability
                if (!$this->product->checkStock($item['id'], $item['quantity'])) {
                    throw new Exception("Insufficient stock for " . $item['name']);
                }
                
                // Create order item
                $this->orderItem->order_id = $order_id;
                $this->orderItem->product_id = $item['id'];
                $this->orderItem->product_name = $item['name'];
                $this->orderItem->price = $item['price'];
                $this->orderItem->quantity = $item['quantity'];
                $this->orderItem->subtotal = $item['price'] * $item['quantity'];
                
                if (!$this->orderItem->create()) {
                    throw new Exception("Failed to create order item");
                }
                
                // Update product stock
                if (!$this->product->updateStock($item['id'], $item['quantity'])) {
                    throw new Exception("Failed to update stock");
                }
            }
            
            // Commit transaction
            $this->db->commit();
            
            // Clear cart
            $_SESSION['cart'] = [];
            $_SESSION['last_order_id'] = $order_id;
            
            // Redirect to success page
            header('Location: index.php?page=order-success&order_id=' . $order_id);
            exit();
            
        } catch (Exception $e) {
            // Rollback transaction
            $this->db->rollback();
            
            error_log("Order placement failed: " . $e->getMessage());
            
            header('Location: index.php?page=checkout&error=failed');
            exit();
        }
    }
}
?>
