<?php
/**
 * Cart Controller - FIXED VERSION
 */

require_once __DIR__ . '/../models/Product.php';

class CartController {
    private $db;
    private $product;
    
    public function __construct($db) {
        $this->db = $db;
        $this->product = new Product($db);
    }
    
    /**
     * Add item to cart - FIXED
     */
    public function add() {
        // Debug: Check if POST data is received
        error_log("Add to Cart - POST data: " . print_r($_POST, true));
        
        if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
            $product_id = intval($_POST['product_id']);
            $quantity = intval($_POST['quantity']);
            
            // Validate quantity
            if ($quantity < 1) {
                $quantity = 1;
            }
            
            // Get product details
            $product = $this->product->getById($product_id);
            
            // Debug: Check if product exists
            error_log("Product found: " . print_r($product, true));
            
            if ($product) {
                // Check stock availability
                if ($this->product->checkStock($product_id, $quantity)) {
                    // Initialize cart if not exists
                    if (!isset($_SESSION['cart'])) {
                        $_SESSION['cart'] = [];
                    }
                    
                    // Add to cart or update quantity
                    if (isset($_SESSION['cart'][$product_id])) {
                        // Update existing item
                        $_SESSION['cart'][$product_id]['quantity'] += $quantity;
                    } else {
                        // Add new item
                        $_SESSION['cart'][$product_id] = [
                            'id' => $product['id'],
                            'name' => $product['name'],
                            'price' => $product['price'],
                            'quantity' => $quantity,
                            'image' => $product['image']
                        ];
                    }
                    
                    // Debug: Check cart contents
                    error_log("Cart after adding: " . print_r($_SESSION['cart'], true));
                    
                    header('Location: index.php?page=cart&status=added');
                    exit();
                } else {
                    // Insufficient stock
                    header('Location: index.php?page=products&error=stock');
                    exit();
                }
            } else {
                // Product not found
                header('Location: index.php?page=products&error=notfound');
                exit();
            }
        }
        
        // Invalid request
        header('Location: index.php?page=products&error=invalid');
        exit();
    }
    
    /**
     * Update cart item quantity
     */
    public function update() {
        if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
            $product_id = intval($_POST['product_id']);
            $quantity = intval($_POST['quantity']);
            
            if ($quantity > 0) {
                // Check stock before updating
                if ($this->product->checkStock($product_id, $quantity)) {
                    if (isset($_SESSION['cart'][$product_id])) {
                        $_SESSION['cart'][$product_id]['quantity'] = $quantity;
                    }
                } else {
                    // If stock insufficient, set to maximum available
                    $product = $this->product->getById($product_id);
                    if ($product && isset($_SESSION['cart'][$product_id])) {
                        $_SESSION['cart'][$product_id]['quantity'] = $product['stock'];
                    }
                }
            } else {
                // Remove item if quantity is 0
                unset($_SESSION['cart'][$product_id]);
            }
        }
        
        header('Location: index.php?page=cart');
        exit();
    }
    
    /**
     * Remove item from cart
     */
    public function remove() {
        if (isset($_GET['id'])) {
            $product_id = intval($_GET['id']);
            unset($_SESSION['cart'][$product_id]);
        }
        
        header('Location: index.php?page=cart');
        exit();
    }
    
    /**
     * Display cart page
     */
    public function view() {
        require_once __DIR__ . '/../views/cart.php';
    }
}
?>
