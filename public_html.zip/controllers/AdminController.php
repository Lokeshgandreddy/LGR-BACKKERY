<?php
/**
 * Admin Controller
 * Handles admin panel operations
 */

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/OrderItem.php';

class AdminController {
    private $db;
    private $user;
    private $order;
    private $orderItem;
    
    /**
     * Constructor
     * @param mysqli $db Database connection
     */
    public function __construct($db) {
        $this->db = $db;
        $this->user = new User($db);
        $this->order = new Order($db);
        $this->orderItem = new OrderItem($db);
    }
    
    /**
     * Check if admin is logged in
     */
    private function checkAuth() {
        if (!isset($_SESSION['admin_id'])) {
            header('Location: index.php?page=admin&view=login');
            exit();
        }
    }
    
    /**
     * Show login page
     */
    public function showLogin() {
        if (isset($_SESSION['admin_id'])) {
            header('Location: index.php?page=admin&view=dashboard');
            exit();
        }
        require_once __DIR__ . '/../views/admin/login.php';
    }
    
    /**
     * Process login
     */
    public function login() {
        $email = htmlspecialchars(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';
        
        if (empty($email) || empty($password)) {
            header('Location: index.php?page=admin&view=login&error=required');
            exit();
        }
        
        $user = $this->user->verifyAdmin($email, $password);
        
        if ($user) {
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_name'] = $user['name'];
            $_SESSION['admin_email'] = $user['email'];
            
            header('Location: index.php?page=admin&view=dashboard');
            exit();
        } else {
            header('Location: index.php?page=admin&view=login&error=invalid');
            exit();
        }
    }
    
    /**
     * Show dashboard
     */
    public function dashboard() {
        $this->checkAuth();
        
        // Get statistics
        $total_orders = $this->db->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'];
        $total_revenue = $this->db->query("SELECT SUM(total_amount) as total FROM orders")->fetch_assoc()['total'] ?? 0;
        $pending_orders = $this->db->query("SELECT COUNT(*) as count FROM orders WHERE status = 'pending'")->fetch_assoc()['count'];
        $total_products = $this->db->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];
        
        require_once __DIR__ . '/../views/admin/dashboard.php';
    }
    
    /**
     * Show orders page
     */
    public function orders() {
        $this->checkAuth();
        
        $orders = $this->order->getAll();
        
        // Get items for each order
        foreach ($orders as &$order) {
            $order['items'] = $this->orderItem->getByOrderId($order['id']);
        }
        
        require_once __DIR__ . '/../views/admin/orders.php';
    }
    
    /**
     * Logout
     */
    public function logout() {
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_name']);
        unset($_SESSION['admin_email']);
        
        header('Location: index.php?page=admin&view=login');
        exit();
    }
}
?>
