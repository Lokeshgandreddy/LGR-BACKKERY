    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>LGR Bakery</h3>
                    <p>Handcrafted breads and patisserie made with love and the finest ingredients.</p>
                    <p style="margin-top: 1rem;">Experience the art of baking with our freshly prepared artisan breads, decadent cakes, and exquisite pastries.</p>
                </div>
                
                <div class="footer-section">
                    <h4>Contact Information</h4>
                    <p><strong>Phone:</strong><br>
                    📞 +91 9951471170<br>
                    📞 +91 40 1234 5678</p>
                    <p style="margin-top: 1rem;"><strong>Email:</strong><br>
                    📧 orders@lgrbakery.in<br>
                    📧 support@lgrbakery.in</p>
                </div>
                
                <div class="footer-section">
                    <h4>Visit Us</h4>
                    <p><strong>Address:</strong><br>
                    Door No. 5, Main Street<br>
                    Jubilee Hills<br>
                    Hyderabad, Telangana - 500033</p>
                    <p style="margin-top: 1rem;"><strong>Hours:</strong><br>
                    Monday - Saturday: 8:00 AM - 9:00 PM<br>
                    Sunday: 8:00 AM - 6:00 PM</p>
                </div>
                
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php#home">Home</a></li>
                        <li><a href="index.php#products">Products</a></li>
                        <li><a href="index.php#about">About Us</a></li>
                        <li><a href="index.php#contact">Contact</a></li>
                        <li><a href="index.php?page=cart">Shopping Cart</a></li>
                        <li><a href="index.php?page=admin">Admin Login</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> LGR Bakery. All rights reserved. | Handcrafted with ❤️ in Hyderabad | Developed by Lokesh Gandreddy</p>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script src="assets/js/main.js"></script>
</body>
</html>
