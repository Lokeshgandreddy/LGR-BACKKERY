/**
 * Main JavaScript File
 * LGR Bakery E-Commerce Platform
 */

// Console log to verify JS is loaded
console.log('✅ LGR Bakery JavaScript Loaded');

/* =========================================
   MOBILE MENU TOGGLE
   ========================================= */
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 DOM Content Loaded');
    
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
            console.log('📱 Mobile menu toggled');
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const isClickInsideNav = navMenu.contains(event.target);
            const isClickOnHamburger = hamburger.contains(event.target);
            
            if (!isClickInsideNav && !isClickOnHamburger && navMenu.classList.contains('active')) {
                navMenu.classList.remove('active');
                hamburger.classList.remove('active');
                console.log('📱 Mobile menu closed');
            }
        });
        
        // Close menu when clicking on a link
        const navLinks = navMenu.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                hamburger.classList.remove('active');
            });
        });
    }
    
    // Create mobile cart icon
    createMobileCartIcon();
    
    // Log all form submissions for debugging
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            console.log('📝 Form submitted:', this.action);
        });
    });
});

/* =========================================
   MOBILE CART ICON
   ========================================= */
function createMobileCartIcon() {
    // Check if cart icon already exists
    if (document.querySelector('.mobile-cart-icon')) {
        return;
    }
    
    // Get cart count from session
    const cartBadge = document.querySelector('.cart-badge');
    const cartCount = cartBadge ? cartBadge.textContent : '0';
    
    // Create mobile cart icon
    const mobileCart = document.createElement('a');
    mobileCart.href = 'index.php?page=cart';
    mobileCart.className = 'mobile-cart-icon';
    mobileCart.innerHTML = `
        🛒
        ${cartCount > 0 ? `<span class="cart-badge">${cartCount}</span>` : ''}
    `;
    
    // Append to body
    document.body.appendChild(mobileCart);
    
    console.log('📱 Mobile cart icon created');
}

/* =========================================
   QUANTITY SELECTOR FUNCTIONS
   ========================================= */
function increaseQty(btn) {
    const input = btn.previousElementSibling;
    const max = parseInt(input.getAttribute('max')) || 999;
    const currentValue = parseInt(input.value) || 1;
    
    if (currentValue < max) {
        input.value = currentValue + 1;
        console.log('➕ Quantity increased to:', input.value);
        
        // Auto-submit form if it's an update form
        if (input.form && input.form.action.includes('action=update')) {
            input.form.submit();
        }
    } else {
        console.warn('⚠️ Maximum quantity reached');
    }
}

function decreaseQty(btn) {
    const input = btn.nextElementSibling;
    const min = parseInt(input.getAttribute('min')) || 1;
    const currentValue = parseInt(input.value) || 1;
    
    if (currentValue > min) {
        input.value = currentValue - 1;
        console.log('➖ Quantity decreased to:', input.value);
        
        // Auto-submit form if it's an update form
        if (input.form && input.form.action.includes('action=update')) {
            input.form.submit();
        }
    } else {
        console.warn('⚠️ Minimum quantity reached');
    }
}

/* =========================================
   FORM VALIDATION
   ========================================= */
document.addEventListener('DOMContentLoaded', function() {
    // Checkout form validation
    const checkoutForm = document.querySelector('.checkout-form');
    
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            const name = document.getElementById('name')?.value.trim();
            const email = document.getElementById('email')?.value.trim();
            const phone = document.getElementById('phone')?.value.trim();
            const address = document.getElementById('address')?.value.trim();
            
            if (!name || !email || !phone || !address) {
                e.preventDefault();
                alert('⚠️ Please fill in all required fields.');
                return false;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('⚠️ Please enter a valid email address.');
                return false;
            }
            
            // Phone validation (basic)
            const phoneRegex = /^[0-9+\-\s()]+$/;
            if (!phoneRegex.test(phone) || phone.length < 10) {
                e.preventDefault();
                alert('⚠️ Please enter a valid phone number.');
                return false;
            }
            
            console.log('✅ Checkout form validated');
            return true;
        });
    }
    
    // Contact form validation
    const contactForm = document.querySelector('.contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Thank you for your message! We will get back to you soon.');
            this.reset();
            console.log('📧 Contact form submitted');
        });
    }
});

/* =========================================
   SMOOTH SCROLL FOR ANCHOR LINKS
   ========================================= */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        
        // Ignore empty hash links
        if (href === '#' || href === '#!') {
            return;
        }
        
        e.preventDefault();
        const target = document.querySelector(href);
        
        if (target) {
            const offsetTop = target.offsetTop - 80; // Account for fixed navbar
            
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
            
            console.log('🔗 Smooth scrolled to:', href);
        }
    });
});

/* =========================================
   AUTO-HIDE ALERTS
   ========================================= */
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.5s ease';
            setTimeout(() => {
                alert.remove();
                console.log('🔔 Alert auto-hidden');
            }, 500);
        }, 5000); // 5 seconds
    });
});

/* =========================================
   ADD TO CART - ENHANCED WITH FEEDBACK
   ========================================= */
document.addEventListener('DOMContentLoaded', function() {
    const addToCartForms = document.querySelectorAll('.add-to-cart-form');
    
    addToCartForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const btn = this.querySelector('.btn-add-cart');
            const originalText = btn.textContent;
            
            // Visual feedback
            btn.textContent = 'Adding...';
            btn.style.opacity = '0.7';
            btn.disabled = true;
            
            const productId = this.querySelector('[name="product_id"]').value;
            const quantity = this.querySelector('[name="quantity"]').value;
            
            console.log('🛒 Add to cart:', {
                productId: productId,
                quantity: quantity
            });
            
            // Reset button after submission (form will redirect)
            setTimeout(() => {
                btn.textContent = originalText;
                btn.style.opacity = '1';
                btn.disabled = false;
            }, 1000);
        });
    });
});

/* =========================================
   SCROLL TO TOP BUTTON
   ========================================= */
document.addEventListener('DOMContentLoaded', function() {
    // Create scroll to top button
    const scrollBtn = document.createElement('button');
    scrollBtn.innerHTML = '↑';
    scrollBtn.className = 'scroll-to-top';
    scrollBtn.style.cssText = `
        position: fixed;
        bottom: 90px;
        right: 20px;
        width: 50px;
        height: 50px;
        background: var(--accent-gold);
        color: var(--black);
        border: none;
        border-radius: 50%;
        font-size: 1.5rem;
        font-weight: 700;
        cursor: pointer;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 998;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    `;
    
    document.body.appendChild(scrollBtn);
    
    // Show/hide scroll button
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            scrollBtn.style.opacity = '1';
            scrollBtn.style.visibility = 'visible';
        } else {
            scrollBtn.style.opacity = '0';
            scrollBtn.style.visibility = 'hidden';
        }
    });
    
    // Scroll to top on click
    scrollBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
        console.log('⬆️ Scrolled to top');
    });
});

/* =========================================
   NAVBAR SCROLL EFFECT
   ========================================= */
let lastScrollTop = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', function() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (scrollTop > lastScrollTop && scrollTop > 100) {
        // Scrolling down
        navbar.style.transform = 'translateY(-100%)';
    } else {
        // Scrolling up
        navbar.style.transform = 'translateY(0)';
    }
    
    // Add shadow on scroll
    if (scrollTop > 10) {
        navbar.style.boxShadow = '0 4px 20px rgba(0,0,0,0.15)';
    } else {
        navbar.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
    }
    
    lastScrollTop = scrollTop;
});

/* =========================================
   PRODUCT CARD ANIMATION ON SCROLL
   ========================================= */
document.addEventListener('DOMContentLoaded', function() {
    const productCards = document.querySelectorAll('.product-card');
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fadeInUp 0.5s ease forwards';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    productCards.forEach(card => {
        card.style.opacity = '0';
        observer.observe(card);
    });
});

/* =========================================
   CART ITEM REMOVE CONFIRMATION
   ========================================= */
document.addEventListener('DOMContentLoaded', function() {
    const removeButtons = document.querySelectorAll('.btn-remove');
    
    removeButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            const confirmed = confirm('Are you sure you want to remove this item from your cart?');
            if (!confirmed) {
                e.preventDefault();
                console.log('🚫 Remove cancelled');
            } else {
                console.log('🗑️ Item removed from cart');
            }
        });
    });
});

/* =========================================
   KEYBOARD ACCESSIBILITY
   ========================================= */
document.addEventListener('keydown', function(e) {
    // Close mobile menu on Escape key
    if (e.key === 'Escape') {
        const navMenu = document.getElementById('navMenu');
        const hamburger = document.getElementById('hamburger');
        
        if (navMenu && navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            hamburger.classList.remove('active');
            console.log('⌨️ Mobile menu closed via Escape key');
        }
    }
});

/* =========================================
   PERFORMANCE OPTIMIZATION
   ========================================= */
// Lazy load images
document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                observer.unobserve(img);
                console.log('🖼️ Image lazy loaded:', img.alt);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
});

/* =========================================
   DEBUG CONSOLE
   ========================================= */
console.log('%c🥖 LGR Bakery E-Commerce Platform', 'font-size: 20px; font-weight: bold; color: #D4AF37;');
console.log('%cDeveloped by Lokesh Gandreddy', 'font-size: 12px; color: #333;');
console.log('%cAll systems operational ✅', 'font-size: 12px; color: #00b894;');
