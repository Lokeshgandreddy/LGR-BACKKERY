<?php
/**
 * Database Configuration
 */

// Database credentials
define('DB_HOST', 'srv1988.hstgr.io');
define('DB_USER', 'u557053954_Lokesh');
define('DB_PASS', 'Lokesh@7070');
define('DB_NAME', 'u557053954_Lokesh');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset
$conn->set_charset("utf8mb4");

?>
