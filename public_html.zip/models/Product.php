<?php
/**
 * Product Model
 */

class Product {
    private $conn;
    private $table = 'products';
    
    public $id;
    public $name;
    public $description;
    public $price;
    public $stock;
    public $image;
    public $category;
    public $created_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Get all products
     */
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " WHERE stock > 0 ORDER BY created_at DESC";
        $result = $this->conn->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Get product by ID
     */
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    /**
     * Update stock
     */
    public function updateStock($id, $quantity) {
        $query = "UPDATE " . $this->table . " SET stock = stock - ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $quantity, $id);
        return $stmt->execute();
    }
    
    /**
     * Check if stock is available
     */
    public function checkStock($id, $quantity) {
        $product = $this->getById($id);
        return $product && $product['stock'] >= $quantity;
    }
}
?>
