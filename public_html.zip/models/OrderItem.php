<?php
/**
 * OrderItem Model
 */

class OrderItem {
    private $conn;
    private $table = 'order_items';
    
    public $id;
    public $order_id;
    public $product_id;
    public $product_name;
    public $price;
    public $quantity;
    public $subtotal;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Create order item
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (order_id, product_id, product_name, price, quantity, subtotal) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param(
            "iisdid",
            $this->order_id,
            $this->product_id,
            $this->product_name,
            $this->price,
            $this->quantity,
            $this->subtotal
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get items by order ID
     */
    public function getByOrderId($order_id) {
        $query = "SELECT * FROM " . $this->table . " WHERE order_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
?>
