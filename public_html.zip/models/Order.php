<?php
/**
 * Order Model
 */

class Order {
    private $conn;
    private $table = 'orders';
    
    public $id;
    public $user_id;
    public $customer_name;
    public $customer_email;
    public $customer_phone;
    public $customer_address;
    public $total_amount;
    public $status;
    public $created_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Create new order
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (user_id, customer_name, customer_email, customer_phone, customer_address, total_amount, status) 
                  VALUES (?, ?, ?, ?, ?, ?, 'pending')";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param(
            "issssd",
            $this->user_id,
            $this->customer_name,
            $this->customer_email,
            $this->customer_phone,
            $this->customer_address,
            $this->total_amount
        );
        
        if ($stmt->execute()) {
            return $this->conn->insert_id;
        }
        return false;
    }
    
    /**
     * Get all orders
     */
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY created_at DESC";
        $result = $this->conn->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Get order by ID
     */
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    /**
     * Get orders by user
     */
    public function getByUser($user_id) {
        $query = "SELECT * FROM " . $this->table . " WHERE user_id = ? ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Update order status
     */
    public function updateStatus($id, $status) {
        $query = "UPDATE " . $this->table . " SET status = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("si", $status, $id);
        return $stmt->execute();
    }
}
?>
