<?php
/**
 * User Model
 */

class User {
    private $conn;
    private $table = 'users';
    
    public $id;
    public $name;
    public $email;
    public $phone;
    public $address;
    public $password;
    public $is_admin;
    public $created_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Create new user
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (name, email, phone, address, password) 
                  VALUES (?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $hashed_password = password_hash($this->password, PASSWORD_DEFAULT);
        
        $stmt->bind_param(
            "sssss",
            $this->name,
            $this->email,
            $this->phone,
            $this->address,
            $hashed_password
        );
        
        if ($stmt->execute()) {
            return $this->conn->insert_id;
        }
        return false;
    }
    
    /**
     * Get user by email
     */
    public function getByEmail($email) {
        $query = "SELECT * FROM " . $this->table . " WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    /**
     * Verify admin login
     */
    public function verifyAdmin($email, $password) {
        $user = $this->getByEmail($email);
        
        if ($user && $user['is_admin'] == 1) {
            if (password_verify($password, $user['password'])) {
                return $user;
            }
        }
        return false;
    }
}
?>
